interface Dress
{
    public void assemble();
}
