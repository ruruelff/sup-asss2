// This is a class definition for a decorator called "CasualDress" that extends another class "DressDecorator".
class CasualDress extends DressDecorator
{
    // Constructor for the CasualDress class, which takes a "Dress" object as a parameter.
    public CasualDress(Dress c)
    {
        // Call the constructor of the parent class (DressDecorator) and pass the "Dress" object to it.
        super(c);
    }

    // Override the "assemble" method from the parent class (DressDecorator).
    @Override
    public void assemble()
    {
        // Call the "assemble" method of the parent class (DressDecorator).
        super.assemble();

        // Print a message indicating that Casual Dress features are being added.
        System.out.println("Adding Casual Dress Features");
    }
}
