// This is a class definition for a decorator called "SportyDress" that extends another class "DressDecorator".
class SportyDress extends DressDecorator
{
    // Constructor for the SportyDress class, which takes a "Dress" object as a parameter.
    public SportyDress(Dress c)
    {
        // Call the constructor of the parent class (DressDecorator) and pass the "Dress" object to it.
        super(c);
    }

    // Override the "assemble" method from the parent class (DressDecorator).
    @Override
    public void assemble()
    {
        // Call the "assemble" method of the parent class (DressDecorator).
        super.assemble();

        // Print a message indicating that Sporty Dress features are being added.
        System.out.println("Adding Sporty Dress Features");
    }
}
